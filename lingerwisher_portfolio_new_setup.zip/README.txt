LINGERWISHER PORTFOLIO

Folder structure:
- index.html
- videos/animation1.mp4 through animation6.mp4
- images/ (optional for future artwork)

To add the six videos:
1. Rename the six files to animation1.mp4 ... animation6.mp4.
2. Put them in the videos folder.
3. Upload the entire project to a NEW GitHub repository.
4. Enable GitHub Pages from main / root.

Do not rename the video files unless you also update index.html.
